import random
import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from .evaluation import evaluate_subset
from .fuzzy import (
    adaptive_membership_params,
    adaptive_fuzzy_utility,
)
from .objective import (
    continuous_ccppo_objective,
    single_task_objective,
)
from .pareto import get_pareto_front
from .scoring import compute_feature_scores
from .stability import compute_bootstrap_stability
from .utils import normalize_array
from .plots import (
    save_convergence_pdf,
    save_detailed_convergence_pdf,
    save_pareto_pdf,
)
def repair_mask(mask, utilities, min_features, max_features):
    mask = mask.copy()

    if mask.sum() < min_features:
        need = min_features - int(mask.sum())
        available = np.where(mask == 0)[0]
        best = available[
            np.argsort(utilities[available])[::-1][:need]
        ]
        mask[best] = 1

    if mask.sum() > max_features:
        remove = int(mask.sum() - max_features)
        selected = np.where(mask == 1)[0]
        worst = selected[
            np.argsort(utilities[selected])[:remove]
        ]
        mask[worst] = 0

    return mask

def run_search(
    X_train,
    y_reg_train,
    X_val,
    y_reg_val,
    y_clf_train,
    y_clf_val,
    cost_df,
    config,
    cache,
):
    features = list(X_train.columns)
    n_features = len(features)
    max_features = min(config.max_features, n_features)

    if config.min_features > max_features:
        raise ValueError(
            f"min_features={config.min_features} exceeds available "
            f"representative features={max_features}."
        )

    if config.verbose:
        print("\nComputing relevance, importance, cost, and stability...")

    score_df = compute_feature_scores(
        X_train,
        y_reg_train,
        y_clf_train,
        cost_df,
        config,
    )

    stability_map = compute_bootstrap_stability(
        X_train,
        y_reg_train,
        y_clf_train,
        cost_df,
        config,
        top_k=min(max_features, n_features),
    )

    score_df["Stability"] = (
        score_df["Feature"].map(stability_map)
    )

    corr = X_train.corr().abs().fillna(0)

    redundancy_feature = []
    for feature in features:
        others = [x for x in features if x != feature]
        redundancy_feature.append(
            corr.loc[feature, others].mean()
            if len(others)
            else 0.0
        )

    score_df["Redundancy_norm"] = normalize_array(
        redundancy_feature
    )

    fuzzy_params = {
        "Relevance": adaptive_membership_params(
            score_df["Relevance"]
        ),
        "Importance": adaptive_membership_params(
            score_df["Importance"]
        ),
        "Cost_norm": adaptive_membership_params(
            score_df["Cost_norm"]
        ),
        "Redundancy_norm": adaptive_membership_params(
            score_df["Redundancy_norm"]
        ),
        "Stability": adaptive_membership_params(
            score_df["Stability"]
        ),
    }

    utilities = np.array([
        adaptive_fuzzy_utility(
            row["Relevance"],
            row["Importance"],
            row["Cost_norm"],
            row["Redundancy_norm"],
            row["Stability"],
            fuzzy_params,
        )
        for _, row in score_df.iterrows()
    ])

    score_df["FuzzyUtility"] = utilities

    population = []

    prob = normalize_array(utilities) + 0.05
    prob = prob / prob.sum()

    for _ in range(config.population_size):
        size = random.randint(
            config.min_features,
            max_features,
        )

        chosen = np.random.choice(
            np.arange(n_features),
            size=size,
            replace=False,
            p=prob,
        )

        mask = np.zeros(n_features, dtype=int)
        mask[chosen] = 1

        mask = repair_mask(
            mask,
            utilities,
            config.min_features,
            max_features,
        )

        population.append(mask)

    archive = []
    history = []

    best_objective = -np.inf
    best_solution = None
    no_improve = 0

    for iteration in range(config.n_iterations):
        results = Parallel(
            n_jobs=config.n_jobs_optimizer,
            prefer="threads",
        )(
            delayed(evaluate_subset)(
                [
                    features[i]
                    for i in np.where(mask == 1)[0]
                ],
                X_train,
                X_val,
                y_reg_train,
                y_reg_val,
                y_clf_train,
                y_clf_val,
                cost_df,
                config,
                cache,
                method="FCAMFS-CCPPO",
                category="Validation",
            )
            for mask in population
        )

        evaluated_population = []

        for idx, mask in enumerate(population):
            metrics = results[idx]

            selected_features_iter = [
                features[i]
                for i in np.where(mask == 1)[0]
            ]

            avg_stability = float(
                np.mean([
                    stability_map[f]
                    for f in selected_features_iter
                ])
            )

            if config.task_mode == "joint":
                objective, feasible = continuous_ccppo_objective(
                    r2=metrics["Yield R²"],
                    f1=metrics["Crop F1"],
                    cost=metrics["Cost"],
                    redundancy=metrics["Redundancy"],
                    stability=avg_stability,
                    subset_size=len(selected_features_iter),
                    total_features=n_features,
                    target_r2=config.target_r2,
                    target_f1=config.target_f1,
                )
            else:
                objective, feasible = single_task_objective(
                    task_mode=config.task_mode,
                    r2=metrics["Yield R²"],
                    f1=metrics["Crop F1"],
                    cost=metrics["Cost"],
                    redundancy=metrics["Redundancy"],
                    stability=avg_stability,
                    subset_size=len(selected_features_iter),
                    total_features=n_features,
                    target_r2=config.target_r2,
                    target_f1=config.target_f1,
                )

            metrics["Objective"] = round(objective, 6)
            metrics["Feasible"] = feasible
            metrics["Stability"] = round(avg_stability, 4)

            evaluated_population.append((mask, metrics))
            archive.append(metrics)

            # Preserved from the paper implementation.
            if objective > best_objective:
                best_objective = objective
                best_solution = mask.copy()
                no_improve = 0
            else:
                no_improve += 1

        best_iter = max(
            evaluated_population,
            key=lambda item: item[1]["Objective"],
        )[1]

        history.append({
            "Iteration": iteration + 1,
            "Best Objective": best_iter["Objective"],
            "Yield R²": best_iter["Yield R²"],
            "Crop F1": best_iter["Crop F1"],
            "Cost": best_iter["Cost"],
            "Redundancy": best_iter["Redundancy"],
            "Stability": best_iter["Stability"],
            "Features": best_iter["Features"],
            "Feasible": best_iter["Feasible"],
        })

        if config.verbose:
            print(
                f"Iter {iteration + 1:03d} | "
                f"Obj={best_iter['Objective']:.4f} | "
                f"R²={best_iter['Yield R²']} | "
                f"F1={best_iter['Crop F1']} | "
                f"Cost={best_iter['Cost']:.2f} | "
                f"Red={best_iter['Redundancy']:.4f} | "
                f"Stab={best_iter['Stability']:.4f} | "
                f"k={best_iter['Features']} | "
                f"Feasible={best_iter['Feasible']}"
            )

        evaluated_population = sorted(
            evaluated_population,
            key=lambda item: item[1]["Objective"],
            reverse=True,
        )

        elites = [
            item[0]
            for item in evaluated_population[
                :max(
                    2,
                    config.population_size
                    // config.elite_fraction_divisor,
                )
            ]
        ]

        new_population = elites.copy()

        while len(new_population) < config.population_size:
            parent_1 = random.choice(elites)
            parent_2 = random.choice(population)

            if n_features > 1:
                crossover_point = random.randint(
                    1,
                    n_features - 1,
                )

                child = np.concatenate([
                    parent_1[:crossover_point],
                    parent_2[crossover_point:],
                ])
            else:
                child = parent_1.copy()

            for i in range(n_features):
                if random.random() < config.mutation_rate:
                    child[i] = 1 - child[i]

            if (
                random.random()
                < config.guided_swap_probability
            ):
                low_selected = np.where(
                    (child == 1)
                    & (utilities < np.median(utilities))
                )[0]

                high_unselected = np.where(
                    (child == 0)
                    & (utilities > np.median(utilities))
                )[0]

                if (
                    len(low_selected) > 0
                    and len(high_unselected) > 0
                ):
                    child[random.choice(low_selected)] = 0
                    child[random.choice(high_unselected)] = 1

            child = repair_mask(
                child,
                utilities,
                config.min_features,
                max_features,
            )

            new_population.append(child)

        population = new_population

        if (
            no_improve
            > config.population_size
            * config.early_stop_multiplier
        ):
            if config.verbose:
                print("\nEarly stopping: objective stabilized.")
            break

    history_df = pd.DataFrame(history)
    archive_df = pd.DataFrame(archive)

    feasible_df = archive_df[
        archive_df["Feasible"] == 1
    ].copy()

    if len(feasible_df) > 0:
        best_row = feasible_df.sort_values(
            by=["Cost", "Redundancy", "Features"],
            ascending=[True, True, True],
        ).iloc[0]

        if config.verbose:
            print(
                "\nFeasible subset found. "
                "Selecting lowest-cost feasible subset."
            )
    else:
        best_row = archive_df.sort_values(
            "Objective",
            ascending=False,
        ).iloc[0]

        if config.verbose:
            print(
                "\nNo feasible subset found. "
                "Selecting best continuous CCPPO subset."
            )

    best_features = list(
        best_row["Selected Features"]
    )

    pareto_df = get_pareto_front(
        archive,
        config.task_mode,
    )

    if config.verbose:
        print("\nBEST ADVANCED FCAMFS-CCPPO SUBSET")
        print("Selected features:", best_features)
        print("Number of features:", len(best_features))
        print("Validation R²:", best_row["Yield R²"])
        print("Validation F1:", best_row["Crop F1"])
        print("Cost:", best_row["Cost"])
        print("Redundancy:", best_row["Redundancy"])
        print("Stability:", best_row["Stability"])
        print("Objective:", best_row["Objective"])

    # ------------------------------------------------------------------
    # Save optimization figures after the search has finished
    # ------------------------------------------------------------------
    save_convergence_pdf(
        history_df,
        "Optimization_Convergence_Normalized.pdf",
    )

    save_detailed_convergence_pdf(
        history_df,
        "Optimization_Convergence_Detailed.pdf",
    )

    save_pareto_pdf(
        archive_df,
        pareto_df,
        config.task_mode,
        "Pareto_Front.pdf",
    )

    return {
        "selected_features": best_features,
        "best_row": best_row.to_dict(),
        "history": history_df,
        "archive": archive_df,
        "pareto": pareto_df,
        "feature_scores": score_df,
        "best_solution_mask": best_solution,
    }