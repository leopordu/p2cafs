import numpy as np

def continuous_ccppo_objective(
    r2,
    f1,
    cost,
    redundancy,
    stability,
    subset_size,
    total_features,
    target_r2,
    target_f1,
):
    r2_gap = max(0.0, target_r2 - r2)
    f1_gap = max(0.0, target_f1 - f1)
    total_gap = r2_gap + f1_gap

    size_penalty = subset_size / total_features
    cost_penalty = np.log1p(cost)

    if total_gap > 0:
        w_r2 = 0.40 + 0.15 * (r2_gap / (total_gap + 1e-10))
        w_f1 = 0.35 + 0.15 * (f1_gap / (total_gap + 1e-10))
        w_stability = 0.10
        w_cost = 0.08
        w_redundancy = 0.07
        w_size = 0.05
    else:
        w_r2 = 0.25
        w_f1 = 0.25
        w_stability = 0.10
        w_cost = 0.20
        w_redundancy = 0.15
        w_size = 0.05

    total_weight = (
        w_r2
        + w_f1
        + w_stability
        + w_cost
        + w_redundancy
        + w_size
    )

    w_r2 /= total_weight
    w_f1 /= total_weight
    w_stability /= total_weight
    w_cost /= total_weight
    w_redundancy /= total_weight
    w_size /= total_weight

    objective = (
        w_r2 * r2
        + w_f1 * f1
        + w_stability * stability
        - w_r2 * r2_gap
        - w_f1 * f1_gap
        - w_cost * cost_penalty
        - w_redundancy * redundancy
        - w_size * size_penalty
    )

    feasible = int(
        (r2 >= target_r2)
        and (f1 >= target_f1)
    )

    return objective, feasible

def single_task_objective(
    task_mode,
    r2,
    f1,
    cost,
    redundancy,
    stability,
    subset_size,
    total_features,
    target_r2,
    target_f1,
):
    size_penalty = subset_size / total_features
    cost_penalty = np.log1p(cost)

    if task_mode == "regression":
        gap = max(0.0, target_r2 - r2)
        performance = r2
        feasible = int(r2 >= target_r2)
    elif task_mode == "classification":
        gap = max(0.0, target_f1 - f1)
        performance = f1
        feasible = int(f1 >= target_f1)
    else:
        raise ValueError("single_task_objective requires regression or classification.")

    objective = (
        0.55 * performance
        + 0.10 * stability
        - 0.20 * cost_penalty
        - 0.10 * redundancy
        - 0.05 * size_penalty
        - 0.55 * gap
    )

    return objective, feasible
