import numpy as np
from sklearn.cluster import AgglomerativeClustering
from .scoring import compute_feature_scores

def representative_feature_selection_auto(
    X,
    y_reg,
    y_clf,
    cost_df,
    config,
):
    best_X = None
    best_representatives = None
    best_groups = None
    best_threshold = None
    best_score = -np.inf

    base_scores = compute_feature_scores(
        X, y_reg, y_clf, cost_df, config
    )

    base_scores["BaseScore"] = (
        0.45 * base_scores["Relevance"]
        + 0.40 * base_scores["Importance"]
        - 0.15 * base_scores["Cost_norm"]
    )

    score_map = dict(
        zip(base_scores["Feature"], base_scores["BaseScore"])
    )

    corr = X.corr().abs().fillna(0)
    distance_matrix = 1 - corr
    np.fill_diagonal(distance_matrix.values, 0.0)

    for threshold in config.representative_thresholds:
        if X.shape[1] <= 1:
            representatives = list(X.columns)
            groups = {f: [f] for f in representatives}
        else:
            try:
                clustering = AgglomerativeClustering(
                    n_clusters=None,
                    metric="precomputed",
                    linkage="average",
                    distance_threshold=1 - threshold,
                )
            except TypeError:
                clustering = AgglomerativeClustering(
                    n_clusters=None,
                    affinity="precomputed",
                    linkage="average",
                    distance_threshold=1 - threshold,
                )

            labels = clustering.fit_predict(distance_matrix)

            representatives = []
            groups = {}

            for label in np.unique(labels):
                group = list(X.columns[labels == label])

                best_feature = max(
                    group,
                    key=lambda f: score_map.get(f, -np.inf),
                )

                representatives.append(best_feature)
                groups[best_feature] = group

        X_rep = X[representatives].copy()

        group_score = np.mean([
            score_map[f] for f in representatives
        ])
        compactness_penalty = 0.01 * len(representatives)
        score = group_score - compactness_penalty

        if score > best_score:
            best_score = score
            best_X = X_rep
            best_representatives = representatives
            best_groups = groups
            best_threshold = threshold

    if config.verbose:
        print("\nRepresentative feature grouping:")
        print("Best threshold:", best_threshold)
        print("Original features:", X.shape[1])
        print("Representative features:", len(best_representatives))

    return (
        best_X,
        best_representatives,
        best_groups,
        best_threshold,
    )
