import numpy as np
import pandas as pd
from sklearn.feature_selection import (
    mutual_info_regression,
    mutual_info_classif,
    f_regression,
)
from sklearn.ensemble import (
    RandomForestRegressor,
    RandomForestClassifier,
    ExtraTreesRegressor,
    ExtraTreesClassifier,
)
from .costs import get_single_feature_cost
from .utils import normalize_array

def compute_feature_scores(X, y_reg, y_clf, cost_df, config):
    features = list(X.columns)

    if y_reg is not None:
        mi_y = mutual_info_regression(
            X, y_reg, random_state=config.random_state
        )
        f_y, _ = f_regression(X, y_reg)
        f_y = np.nan_to_num(f_y)
    else:
        mi_y = np.zeros(len(features))
        f_y = np.zeros(len(features))

    if y_clf is not None:
        mi_c = mutual_info_classif(
            X, y_clf, random_state=config.random_state
        )
    else:
        mi_c = np.zeros(len(features))

    if config.task_mode == "joint":
        relevance = (
            0.40 * normalize_array(mi_y)
            + 0.25 * normalize_array(f_y)
            + 0.35 * normalize_array(mi_c)
        )
    elif config.task_mode == "regression":
        relevance = (
            0.60 * normalize_array(mi_y)
            + 0.40 * normalize_array(f_y)
        )
    else:
        relevance = normalize_array(mi_c)

    rf_reg_imp = et_reg_imp = np.zeros(len(features))
    rf_clf_imp = et_clf_imp = np.zeros(len(features))

    if y_reg is not None:
        rf_reg = RandomForestRegressor(
            n_estimators=config.score_estimators,
            random_state=config.random_state,
            n_jobs=config.n_jobs_scoring,
        )
        et_reg = ExtraTreesRegressor(
            n_estimators=config.score_estimators,
            random_state=config.random_state,
            n_jobs=config.n_jobs_scoring,
        )
        rf_reg.fit(X, y_reg)
        et_reg.fit(X, y_reg)
        rf_reg_imp = rf_reg.feature_importances_
        et_reg_imp = et_reg.feature_importances_

    if y_clf is not None:
        rf_clf = RandomForestClassifier(
            n_estimators=config.score_estimators,
            random_state=config.random_state,
            n_jobs=config.n_jobs_scoring,
        )
        et_clf = ExtraTreesClassifier(
            n_estimators=config.score_estimators,
            random_state=config.random_state,
            n_jobs=config.n_jobs_scoring,
        )
        rf_clf.fit(X, y_clf)
        et_clf.fit(X, y_clf)
        rf_clf_imp = rf_clf.feature_importances_
        et_clf_imp = et_clf.feature_importances_

    if config.task_mode == "joint":
        importance = (
            0.30 * normalize_array(rf_reg_imp)
            + 0.25 * normalize_array(rf_clf_imp)
            + 0.25 * normalize_array(et_reg_imp)
            + 0.20 * normalize_array(et_clf_imp)
        )
    elif config.task_mode == "regression":
        importance = (
            0.55 * normalize_array(rf_reg_imp)
            + 0.45 * normalize_array(et_reg_imp)
        )
    else:
        importance = (
            0.55 * normalize_array(rf_clf_imp)
            + 0.45 * normalize_array(et_clf_imp)
        )

    costs = np.array([
        get_single_feature_cost(feature, cost_df, config)
        for feature in features
    ])
    cost_norm = normalize_array(costs)

    return pd.DataFrame({
        "Feature": features,
        "Relevance": relevance,
        "Importance": importance,
        "Cost": costs,
        "Cost_norm": cost_norm,
    })
