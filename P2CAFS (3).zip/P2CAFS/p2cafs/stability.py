import numpy as np
import pandas as pd
from .scoring import compute_feature_scores

def compute_bootstrap_stability(
    X,
    y_reg,
    y_clf,
    cost_df,
    config,
    top_k,
):
    features = list(X.columns)
    counts = {feature: 0 for feature in features}

    for _ in range(config.bootstraps):
        idx = np.random.choice(
            len(X),
            size=len(X),
            replace=True,
        )

        X_b = X.iloc[idx].reset_index(drop=True)

        y_reg_b = (
            pd.Series(y_reg).iloc[idx].reset_index(drop=True)
            if y_reg is not None
            else None
        )

        y_clf_b = (
            pd.Series(y_clf).iloc[idx].reset_index(drop=True)
            if y_clf is not None
            else None
        )

        scores = compute_feature_scores(
            X_b,
            y_reg_b,
            y_clf_b,
            cost_df,
            config,
        )

        scores["Combined"] = (
            0.45 * scores["Relevance"]
            + 0.45 * scores["Importance"]
            - 0.10 * scores["Cost_norm"]
        )

        selected = (
            scores
            .sort_values("Combined", ascending=False)["Feature"]
            .head(top_k)
        )

        for feature in selected:
            counts[feature] += 1

    return {
        feature: counts[feature] / config.bootstraps
        for feature in features
    }
