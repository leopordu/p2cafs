import os
import random
import numpy as np

def seed_everything(seed: int) -> None:
    np.random.seed(seed)
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

def normalize_array(values):
    values = np.asarray(values, dtype=float)
    values = np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)
    if values.max() == values.min():
        return np.zeros_like(values)
    return (values - values.min()) / (values.max() - values.min() + 1e-10)

def safe_stratify(y):
    if y is None:
        return None
    y = np.asarray(y)
    _, counts = np.unique(y, return_counts=True)
    if len(counts) == 0 or np.min(counts) < 2:
        return None
    return y
