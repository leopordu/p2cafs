from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from .utils import safe_stratify

@dataclass
class PreparedData:
    X: pd.DataFrame
    y_reg: object
    y_clf: object
    regression_target: object
    classification_target: object
    class_encoder: object
    leakage_columns: list
    removed_columns: list

@dataclass
class SplitData:
    X_train_full: pd.DataFrame
    X_test: pd.DataFrame
    y_reg_train_full: object
    y_reg_test: object
    y_clf_train_full: object
    y_clf_test: object
    X_train: pd.DataFrame
    X_val: pd.DataFrame
    y_reg_train: object
    y_reg_val: object
    y_clf_train: object
    y_clf_val: object

def detect_column_by_keywords(df, keywords):
    for col in df.columns:
        clean = col.lower().replace(" ", "_").replace("-", "_")
        if any(k in clean for k in keywords):
            return col
    return None

def prepare_dataset(df, config):
    data = df.copy()

    reg_col = config.regression_target
    clf_col = config.classification_target

    if config.task_mode in {"joint", "regression"} and reg_col is None:
        reg_col = detect_column_by_keywords(
            data, config.regression_target_keywords
        )

    if config.task_mode in {"joint", "classification"} and clf_col is None:
        clf_col = detect_column_by_keywords(
            data, config.classification_target_keywords
        )

    if config.task_mode in {"joint", "regression"} and reg_col is None:
        raise ValueError("No regression target column detected.")

    if config.task_mode in {"joint", "classification"} and clf_col is None:
        raise ValueError("No classification target column detected.")

    leakage_cols = [
        col for col in data.columns
        if any(k in col.lower() for k in config.leakage_keywords)
        and col not in [reg_col, clf_col]
    ]

    data = data.drop(columns=leakage_cols, errors="ignore")

    y_reg = None
    if reg_col is not None:
        y_reg = pd.to_numeric(data[reg_col], errors="raise").astype(float)

    class_encoder = None
    y_clf = None
    if clf_col is not None:
        class_encoder = LabelEncoder()
        y_clf = class_encoder.fit_transform(data[clf_col].astype(str))

    X = data.drop(
        columns=[c for c in [reg_col, clf_col] if c is not None],
        errors="ignore"
    )

    remove_cols = [
        col for col in X.columns
        if any(k in col.lower() for k in config.remove_keywords)
    ]
    remove_cols.extend([
        c for c in config.extra_exclude_columns if c in X.columns
    ])
    remove_cols = list(dict.fromkeys(remove_cols))

    X = X.drop(columns=remove_cols, errors="ignore")

    for col in X.columns:
        if X[col].dtype == "object":
            X[col] = LabelEncoder().fit_transform(X[col].astype(str))

    X = X.select_dtypes(include=[np.number])
    X = X.replace([np.inf, -np.inf], np.nan)
    X = X.fillna(X.median(numeric_only=True))

    constant_cols = [
        col for col in X.columns
        if X[col].nunique() <= 1
    ]
    X = X.drop(columns=constant_cols, errors="ignore")

    if config.verbose:
        print("Detected regression column:", reg_col)
        print("Detected classification column:", clf_col)
        print("Removed leakage columns:", leakage_cols)
        print("Removed non-feature columns:", remove_cols)
        print("Usable features:", X.shape[1])

    return PreparedData(
        X=X,
        y_reg=y_reg,
        y_clf=y_clf,
        regression_target=reg_col,
        classification_target=clf_col,
        class_encoder=class_encoder,
        leakage_columns=leakage_cols,
        removed_columns=remove_cols,
    )

def split_dataset(prepared, config):
    arrays = [prepared.X]
    if prepared.y_reg is not None:
        arrays.append(prepared.y_reg)
    if prepared.y_clf is not None:
        arrays.append(prepared.y_clf)

    outer = train_test_split(
        *arrays,
        test_size=config.test_size,
        random_state=config.random_state,
        stratify=safe_stratify(prepared.y_clf),
    )

    i = 0
    X_train_full, X_test = outer[i], outer[i + 1]
    i += 2

    y_reg_train_full = y_reg_test = None
    if prepared.y_reg is not None:
        y_reg_train_full, y_reg_test = outer[i], outer[i + 1]
        i += 2

    y_clf_train_full = y_clf_test = None
    if prepared.y_clf is not None:
        y_clf_train_full, y_clf_test = outer[i], outer[i + 1]

    arrays = [X_train_full]
    if y_reg_train_full is not None:
        arrays.append(y_reg_train_full)
    if y_clf_train_full is not None:
        arrays.append(y_clf_train_full)

    inner = train_test_split(
        *arrays,
        test_size=config.validation_size,
        random_state=config.random_state,
        stratify=safe_stratify(y_clf_train_full),
    )

    i = 0
    X_train, X_val = inner[i], inner[i + 1]
    i += 2

    y_reg_train = y_reg_val = None
    if y_reg_train_full is not None:
        y_reg_train, y_reg_val = inner[i], inner[i + 1]
        i += 2

    y_clf_train = y_clf_val = None
    if y_clf_train_full is not None:
        y_clf_train, y_clf_val = inner[i], inner[i + 1]

    return SplitData(
        X_train_full=X_train_full,
        X_test=X_test,
        y_reg_train_full=y_reg_train_full,
        y_reg_test=y_reg_test,
        y_clf_train_full=y_clf_train_full,
        y_clf_test=y_clf_test,
        X_train=X_train,
        X_val=X_val,
        y_reg_train=y_reg_train,
        y_reg_val=y_reg_val,
        y_clf_train=y_clf_train,
        y_clf_val=y_clf_val,
    )
