import numpy as np
import pandas as pd

def get_single_feature_cost(feature, cost_df, config):
    feature_clean = str(feature).strip().lower()

    if config.feature_name_column not in cost_df.columns:
        raise ValueError(
            f"Missing cost feature column '{config.feature_name_column}'. "
            f"Available columns: {cost_df.columns.tolist()}"
        )

    temp = cost_df.copy()
    temp["Feature_clean"] = (
        temp[config.feature_name_column]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    row = temp[temp["Feature_clean"] == feature_clean]

    if row.empty:
        return float(config.missing_feature_cost)
    
    sensor_cost = pd.to_numeric(
        row.iloc[0].get(config.sensor_cost_column, np.nan),
        errors="coerce",
    )

    lab_cost = pd.to_numeric(
        row.iloc[0].get(config.lab_cost_column, np.nan),
        errors="coerce",
    )

    valid_costs = []

    if pd.notna(sensor_cost) and sensor_cost > 0:
        valid_costs.append(float(sensor_cost))

    if pd.notna(lab_cost) and lab_cost > 0:
        valid_costs.append(float(lab_cost))
    if len(valid_costs) == 0:

        explicit_zero = (
            (pd.notna(sensor_cost) and float(sensor_cost) == 0.0)
            or
            (pd.notna(lab_cost) and float(lab_cost) == 0.0)
        )

        if explicit_zero:
            return 0.0

        return float(config.no_valid_cost)


    return min(valid_costs)

def get_feature_cost(features, cost_df, config):
    return float(
        sum(
            get_single_feature_cost(feature, cost_df, config)
            for feature in features
        )
    )
