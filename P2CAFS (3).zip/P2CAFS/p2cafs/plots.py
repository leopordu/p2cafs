import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.preprocessing import MinMaxScaler


def save_convergence_pdf(history_df, output_path):
    plot_df = history_df.copy()

    rename_map = {
        "Best Objective": "Objective",
        "Yield R²": "R2",
        "Crop F1": "F1",
        "Redundancy": "Red",
    }
    plot_df = plot_df.rename(columns=rename_map)

    metrics = [
        metric
        for metric in [
            "Objective",
            "R2",
            "F1",
            "Cost",
            "Red",
            "Stability",
        ]
        if metric in plot_df.columns
        and not plot_df[metric].isna().all()
    ]

    scaler = MinMaxScaler()
    normalized = scaler.fit_transform(plot_df[metrics])

    normalized_df = pd.DataFrame(
        normalized,
        columns=metrics,
    )
    normalized_df["Iteration"] = plot_df["Iteration"].values

    fig, ax = plt.subplots(figsize=(11, 6))

    for metric in metrics:
        ax.plot(
            normalized_df["Iteration"],
            normalized_df[metric],
            marker="o",
            linewidth=2,
            markersize=4,
            label=metric,
        )

    ax.set_xlabel("Iteration")
    ax.set_ylabel("Normalized Value")
    ax.set_title("FCAMFS-CCPPO Optimization Convergence")
    ax.grid(True, linestyle="--", alpha=0.4)
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))

    fig.tight_layout()
    fig.savefig(output_path, format="pdf", bbox_inches="tight")
    plt.close(fig)


def save_pareto_pdf(archive_df, pareto_df, task_mode, output_path):
    with PdfPages(output_path) as pdf:

        if task_mode in {"joint", "regression"}:
            fig, ax = plt.subplots(figsize=(8, 6))

            ax.scatter(
                archive_df["Cost"],
                archive_df["Yield R²"],
                alpha=0.4,
                label="All searched subsets",
            )

            ax.scatter(
                pareto_df["Cost"],
                pareto_df["Yield R²"],
                marker="x",
                label="Pareto front",
            )

            ax.set_xlabel("Acquisition Cost")
            ax.set_ylabel("Yield R²")
            ax.set_title("Pareto Front: Cost vs Regression Performance")
            ax.legend()
            ax.grid(True)
            fig.tight_layout()

            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

        if task_mode in {"joint", "classification"}:
            fig, ax = plt.subplots(figsize=(8, 6))

            ax.scatter(
                archive_df["Cost"],
                archive_df["Crop F1"],
                alpha=0.4,
                label="All searched subsets",
            )

            ax.scatter(
                pareto_df["Cost"],
                pareto_df["Crop F1"],
                marker="x",
                label="Pareto front",
            )

            ax.set_xlabel("Acquisition Cost")
            ax.set_ylabel("Classification F1-score")
            ax.set_title("Pareto Front: Cost vs Classification Performance")
            ax.legend()
            ax.grid(True)
            fig.tight_layout()

            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)


def save_detailed_convergence_pdf(history_df, output_path):
    plot_df = history_df.copy()

    plot_df = plot_df.rename(columns={
        "Best Objective": "Objective",
        "Yield R²": "R2",
        "Crop F1": "F1",
        "Redundancy": "Red",
    })

    metrics = [
        metric
        for metric in [
            "Objective",
            "R2",
            "F1",
            "Cost",
            "Red",
            "Stability",
        ]
        if metric in plot_df.columns
        and not plot_df[metric].isna().all()
    ]

    fig, axes = plt.subplots(
        nrows=len(metrics),
        ncols=1,
        figsize=(10, 2.3 * len(metrics)),
        sharex=True,
    )

    if len(metrics) == 1:
        axes = [axes]

    for i, metric in enumerate(metrics):
        axes[i].plot(
            plot_df["Iteration"],
            plot_df[metric],
            marker="o",
            linewidth=2,
            markersize=3,
        )

        axes[i].set_ylabel(metric, fontsize=10)
        axes[i].grid(True, linestyle="--", alpha=0.5)

    axes[-1].set_xlabel("Iteration", fontsize=12)

    fig.suptitle(
        "FCAMFS-CCPPO Optimization Convergence (Raw Physical Units)",
        fontsize=14,
    )

    fig.tight_layout(rect=[0, 0, 1, 0.97])

    fig.savefig(
        output_path,
        format="pdf",
        bbox_inches="tight",
    )

    plt.close(fig)

