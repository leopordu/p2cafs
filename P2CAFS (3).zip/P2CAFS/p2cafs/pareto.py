import pandas as pd

def dominates(a, b, task_mode):
    performance_conditions = []
    strict_conditions = []

    if task_mode in {"joint", "regression"}:
        performance_conditions.append(a["Yield R²"] >= b["Yield R²"])
        strict_conditions.append(a["Yield R²"] > b["Yield R²"])

    if task_mode in {"joint", "classification"}:
        performance_conditions.append(a["Crop F1"] >= b["Crop F1"])
        strict_conditions.append(a["Crop F1"] > b["Crop F1"])

    return (
        all(performance_conditions)
        and a["Cost"] <= b["Cost"]
        and a["Redundancy"] <= b["Redundancy"]
        and (
            any(strict_conditions)
            or a["Cost"] < b["Cost"]
            or a["Redundancy"] < b["Redundancy"]
        )
    )

def get_pareto_front(results, task_mode):
    pareto = []

    for i, result in enumerate(results):
        dominated_flag = False

        for j, other in enumerate(results):
            if i != j and dominates(other, result, task_mode):
                dominated_flag = True
                break

        if not dominated_flag:
            pareto.append(result)

    return pd.DataFrame(pareto)
