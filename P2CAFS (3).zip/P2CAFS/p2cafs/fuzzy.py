import numpy as np

def triangular(x, a, b, c):
    if x <= a or x >= c:
        return 0.0
    if x == b:
        return 1.0
    if x < b:
        return (x - a) / (b - a + 1e-10)
    return (c - x) / (c - b + 1e-10)

def adaptive_membership_params(values):
    values = np.asarray(values, dtype=float)
    values = np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)

    if values.max() == values.min():
        v = float(values[0])
        return {
            "low": (v - 1e-6, v, v + 1e-6),
            "medium": (v - 1e-6, v, v + 1e-6),
            "high": (v - 1e-6, v, v + 1e-6),
        }

    q10 = np.percentile(values, 10)
    q25 = np.percentile(values, 25)
    q50 = np.percentile(values, 50)
    q75 = np.percentile(values, 75)
    q90 = np.percentile(values, 90)

    return {
        "low": (q10, q25, q50),
        "medium": (q25, q50, q75),
        "high": (q50, q75, q90),
    }

def fuzzy_level_adaptive(x, params):
    return {
        "low": triangular(x, *params["low"]),
        "medium": triangular(x, *params["medium"]),
        "high": triangular(x, *params["high"]),
    }

def adaptive_fuzzy_utility(
    relevance,
    importance,
    cost,
    redundancy,
    stability,
    fuzzy_params,
):
    rel = fuzzy_level_adaptive(relevance, fuzzy_params["Relevance"])
    imp = fuzzy_level_adaptive(importance, fuzzy_params["Importance"])
    cst = fuzzy_level_adaptive(cost, fuzzy_params["Cost_norm"])
    red = fuzzy_level_adaptive(redundancy, fuzzy_params["Redundancy_norm"])
    stb = fuzzy_level_adaptive(stability, fuzzy_params["Stability"])

    rules = []

    rules.append((
        min(
            rel["high"],
            imp["high"],
            stb["high"],
            cst["low"],
            red["low"],
        ),
        0.95,
    ))
    rules.append((min(rel["high"], imp["high"], stb["medium"]), 0.85))
    rules.append((min(rel["high"], imp["medium"], cst["low"]), 0.75))
    rules.append((min(rel["medium"], imp["high"], stb["high"]), 0.75))
    rules.append((
        min(
            rel["medium"],
            imp["medium"],
            cst["low"],
            red["low"],
        ),
        0.65,
    ))
    rules.append((min(rel["medium"], imp["medium"], stb["medium"]), 0.60))
    rules.append((min(cst["low"], red["low"], stb["high"]), 0.70))
    rules.append((max(cst["high"], red["high"]), 0.25))
    rules.append((min(stb["low"], rel["low"]), 0.10))
    rules.append((min(rel["low"], imp["low"]), 0.15))

    numerator = sum(weight * value for weight, value in rules)
    denominator = sum(weight for weight, _ in rules)

    if denominator == 0:
        return (
            0.30 * relevance
            + 0.30 * importance
            + 0.20 * stability
            + 0.10 * (1 - cost)
            + 0.10 * (1 - redundancy)
        )

    return numerator / denominator
