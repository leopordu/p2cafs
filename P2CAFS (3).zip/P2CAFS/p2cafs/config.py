from dataclasses import dataclass, field
from typing import Optional, Sequence, Literal

TaskMode = Literal["joint", "regression", "classification"]

@dataclass
class P2CAFSConfig:
    task_mode: TaskMode = "joint"

    regression_target: Optional[str] = None
    classification_target: Optional[str] = None

    regression_target_keywords: Sequence[str] = (
        "yield", "production", "prod"
    )
    classification_target_keywords: Sequence[str] = (
        "crop", "crp", "commodity", "species", "class"
    )

    leakage_keywords: Sequence[str] = (
        "req", "required", "requirement", "recommend", "recommended",
        "target", "label", "output", "yield_class"
    )
    remove_keywords: Sequence[str] = (
        "id", "name", "district", "center", "region",
        "state", "country", "date"
    )
    extra_exclude_columns: Sequence[str] = field(default_factory=tuple)

    target_r2: float = 1
    target_f1: float = 1

    population_size: int = 30
    n_iterations: int = 60
    min_features: int = 2
    max_features: int = 25

    bootstraps: int = 10
    representative_thresholds: Sequence[float] = (0.85, 0.90, 0.95)

    test_size: float = 0.30
    validation_size: float = 0.25
    random_state: int = 42

    feature_name_column: str = "Feature"
    sensor_cost_column: str = "cost_sensors"
    lab_cost_column: str = "cost_lab"
    missing_feature_cost: float = 9999.0
    no_valid_cost: float = 9999.0

    score_estimators: int = 250
    evaluation_estimators: int = 250

    n_jobs_scoring: int = -1
    n_jobs_optimizer: int = -1
    n_jobs_evaluation: int = 1

    mutation_rate: float = 0.05
    guided_swap_probability: float = 0.30
    elite_fraction_divisor: int = 5
    early_stop_multiplier: int = 10

    verbose: bool = True

    def validate(self) -> None:
        if self.task_mode not in {"joint", "regression", "classification"}:
            raise ValueError("task_mode must be joint, regression, or classification.")
        if self.task_mode in {"joint", "regression"} and self.regression_target is None:
            # Allowed because keyword detection may be used.
            pass
        if self.task_mode in {"joint", "classification"} and self.classification_target is None:
            # Allowed because keyword detection may be used.
            pass
        if self.min_features < 1:
            raise ValueError("min_features must be at least 1.")
        if self.max_features < self.min_features:
            raise ValueError("max_features must be >= min_features.")
        if not 0 < self.test_size < 1:
            raise ValueError("test_size must be between 0 and 1.")
        if not 0 < self.validation_size < 1:
            raise ValueError("validation_size must be between 0 and 1.")
