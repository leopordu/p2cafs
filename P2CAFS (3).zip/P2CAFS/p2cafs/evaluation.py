import numpy as np
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import (
    r2_score,
    mean_squared_error,
    mean_absolute_error,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)
from .costs import get_feature_cost

def get_redundancy(X, features):
    if len(features) <= 1:
        return 0.0

    corr = X[features].corr().abs()
    vals = corr.values[
        np.triu_indices(len(features), k=1)
    ]

    if len(vals) == 0:
        return 0.0

    return float(np.nanmean(vals))

def evaluate_subset(
    features,
    X_train,
    X_eval,
    y_reg_train,
    y_reg_eval,
    y_clf_train,
    y_clf_eval,
    cost_df,
    config,
    cache,
    method="FCAMFS",
    category="Proposed",
):
    features = list(features)

    feature_key = (
        tuple(sorted(features)),
        id(X_train),
        id(X_eval),
        0 if y_reg_train is None else len(y_reg_train),
        0 if y_reg_eval is None else len(y_reg_eval),
    )

    if feature_key in cache:
        cached = cache[feature_key].copy()
        cached["Method"] = method
        cached["Category"] = category
        return cached

    result = {
        "Category": category,
        "Method": method,
        "Features": len(features),
        "Selected Features": features,
        "Cost": round(
            get_feature_cost(features, cost_df, config),
            4,
        ),
        "Redundancy": round(
            get_redundancy(X_train, features),
            4,
        ),
    }

    if y_reg_train is not None:
        reg_model = RandomForestRegressor(
            n_estimators=config.evaluation_estimators,
            random_state=config.random_state,
            n_jobs=config.n_jobs_evaluation,
        )

        reg_model.fit(X_train[features], y_reg_train)
        y_pred = reg_model.predict(X_eval[features])

        result.update({
            "Yield R²": round(r2_score(y_reg_eval, y_pred), 4),
            "Yield RMSE": round(
                np.sqrt(mean_squared_error(y_reg_eval, y_pred)),
                6,
            ),
            "Yield MAE": round(
                mean_absolute_error(y_reg_eval, y_pred),
                6,
            ),
        })
    else:
        result.update({
            "Yield R²": np.nan,
            "Yield RMSE": np.nan,
            "Yield MAE": np.nan,
        })

    if y_clf_train is not None:
        clf_model = RandomForestClassifier(
            n_estimators=config.evaluation_estimators,
            random_state=config.random_state,
            n_jobs=config.n_jobs_evaluation,
        )

        clf_model.fit(X_train[features], y_clf_train)
        crop_pred = clf_model.predict(X_eval[features])

        result.update({
            "Crop Accuracy": round(
                accuracy_score(y_clf_eval, crop_pred),
                4,
            ),
            "Crop Precision": round(
                precision_score(
                    y_clf_eval,
                    crop_pred,
                    average="weighted",
                    zero_division=0,
                ),
                4,
            ),
            "Crop Recall": round(
                recall_score(
                    y_clf_eval,
                    crop_pred,
                    average="weighted",
                    zero_division=0,
                ),
                4,
            ),
            "Crop F1": round(
                f1_score(
                    y_clf_eval,
                    crop_pred,
                    average="weighted",
                    zero_division=0,
                ),
                4,
            ),
        })
    else:
        result.update({
            "Crop Accuracy": np.nan,
            "Crop Precision": np.nan,
            "Crop Recall": np.nan,
            "Crop F1": np.nan,
        })

    cache[feature_key] = result.copy()
    return result
