import time
from pathlib import Path
import pandas as pd

from .config import P2CAFSConfig
from .data import prepare_dataset, split_dataset
from .evaluation import evaluate_subset
from .grouping import representative_feature_selection_auto
from .optimizer import run_search
from .plots import save_convergence_pdf, save_pareto_pdf,save_detailed_convergence_pdf
from .utils import seed_everything

class P2CAFSFramework:
    def __init__(self, config=None):
        self.config = config or P2CAFSConfig()
        self.config.validate()

        self.prepared = None
        self.split = None
        self.grouped_X = None
        self.representatives = None
        self.groups = None
        self.best_threshold = None

        self.output = None
        self.test_result = None
        self.runtime_seconds = None
        self.subset_cache = {}

    def fit(self, data, cost_data):
        config = self.config

        seed_everything(config.random_state)
        self.subset_cache = {}

        self.prepared = prepare_dataset(
            data,
            config,
        )

        (
            self.grouped_X,
            self.representatives,
            self.groups,
            self.best_threshold,
        ) = representative_feature_selection_auto(
            X=self.prepared.X,
            y_reg=self.prepared.y_reg,
            y_clf=self.prepared.y_clf,
            cost_df=cost_data,
            config=config,
        )

        self.prepared.X = self.grouped_X

        self.split = split_dataset(
            self.prepared,
            config,
        )

        start = time.perf_counter()

        self.output = run_search(
            X_train=self.split.X_train,
            y_reg_train=self.split.y_reg_train,
            X_val=self.split.X_val,
            y_reg_val=self.split.y_reg_val,
            y_clf_train=self.split.y_clf_train,
            y_clf_val=self.split.y_clf_val,
            cost_df=cost_data,
            config=config,
            cache=self.subset_cache,
        )

        self.runtime_seconds = (
            time.perf_counter() - start
        )

        self.test_result = evaluate_subset(
            features=self.output["selected_features"],
            X_train=self.split.X_train_full,
            X_eval=self.split.X_test,
            y_reg_train=self.split.y_reg_train_full,
            y_reg_eval=self.split.y_reg_test,
            y_clf_train=self.split.y_clf_train_full,
            y_clf_eval=self.split.y_clf_test,
            cost_df=cost_data,
            config=config,
            cache=self.subset_cache,
            method="Advanced FCAMFS-CCPPO",
            category="Proposed",
        )

        self.test_result["Runtime (s)"] = round(
            self.runtime_seconds,
            4,
        )

        return self

    def selected_features(self):
        if self.output is None:
            raise RuntimeError("Call fit() first.")
        return self.output["selected_features"]

    def best_validation_result(self):
        if self.output is None:
            raise RuntimeError("Call fit() first.")
        return dict(self.output["best_row"])

    def final_test_result(self):
        if self.test_result is None:
            raise RuntimeError("Call fit() first.")
        return dict(self.test_result)

    def save_outputs(self, output_dir="outputs"):
        if self.output is None:
            raise RuntimeError("Call fit() first.")

        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        self.output["history"].to_excel(
            out / "history.xlsx",
            index=False,
        )
        self.output["archive"].to_excel(
            out / "archive.xlsx",
            index=False,
        )
        self.output["pareto"].to_excel(
            out / "pareto.xlsx",
            index=False,
        )
        self.output["feature_scores"].to_excel(
            out / "feature_scores.xlsx",
            index=False,
        )

        pd.DataFrame({
            "Selected Feature":
                self.output["selected_features"]
        }).to_excel(
            out / "selected_features.xlsx",
            index=False,
        )

        pd.DataFrame([
            self.test_result
        ]).to_excel(
            out / "final_test.xlsx",
            index=False,
        )

        pd.DataFrame([
            {
                "Representative Feature": representative,
                "Grouped Features": ", ".join(members),
            }
            for representative, members in self.groups.items()
        ]).to_excel(
            out / "representative_groups.xlsx",
            index=False,
        )
        save_convergence_pdf(
            self.output["history"],
            out / "optimization_convergence.pdf",
        )

        save_detailed_convergence_pdf(
            self.output["history"],
            out / "optimization_convergence_detailed.pdf",
        )

        save_pareto_pdf(
            self.output["archive"],
            self.output["pareto"],
            self.config.task_mode,
            out / "pareto_front.pdf",
        )

     
        if self.config.verbose:
            print("\nSaved outputs to:", out.resolve())
