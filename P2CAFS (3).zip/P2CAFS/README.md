# P²CAFS: Performance-Preserving Cost-Aware Feature Selection

## Overview

P²CAFS is a feature-selection framework that considers predictive performance and feature-acquisition cost. It supports three operating modes: joint regression and classification, classification only, and regression only. The repository provides the Python implementation, eight benchmark datasets, feature-acquisition cost workbooks, and Jupyter notebooks for running the experiments.

## Repository contents

```text
P2CAFS/
├── p2cafs/                                        # Python implementation
├── 01_Classification.ipynb                       # Classification experiments
├── 02_Regression_Baseline_Comparison_MINIMAL_EDIT.ipynb
├── 03_Joint_Baseline_Comparison.ipynb             # Joint-task experiments
├── Dataset_I_Agriculture.csv
├── Dataset_II_Agriculture.csv
├── Dataset_III_Agriculture.csv
├── Dataset_IV_Agriculture.csv
├── Dataset_V_Manufacturing.csv
├── Dataset_VI_Water_Potability.csv
├── Dataset_VII_Chronic_Kidney_Disease.csv
├── Dataset_VIII_Diabetes.csv
├── Features_cost_updated_all_116_features.xlsx
├── Cost_Manufacturing_Feature_Acquisition_Costs.xlsx
├── Cost_Water_Potability_Feature_Acquisition_Costs.xlsx
├── Cost_Kidney_Disease_Feature_Acquisition_Cos_.xlsx
├── cost_Diabetes_Progression_Feature.xlsx
├── requirements.txt
└── README.md
```

## Datasets

| Dataset | Domain | Records | Operating mode | Filename |
|---|---|---:|---|---|
| I | Agriculture | 454 | Joint | `Dataset_I_Agriculture.csv` |
| II | Agriculture | 36,520 | Joint | `Dataset_II_Agriculture.csv` |
| III | Agriculture | 242,696 | Joint | `Dataset_III_Agriculture.csv` |
| IV | Agriculture | 50,765 | Joint | `Dataset_IV_Agriculture.csv` |
| V | Manufacturing | 10,000 | Joint | `Dataset_V_Manufacturing.csv` |
| VI | Water potability | 3,276 | Classification | `Dataset_VI_Water_Potability.csv` |
| VII | Chronic kidney disease | 400 | Classification | `Dataset_VII_Chronic_Kidney_Disease.csv` |
| VIII | Diabetes | 442 | Regression | `Dataset_VIII_Diabetes.csv` |

## Feature-acquisition cost files

| Dataset(s) | Cost workbook |
|---|---|
| I–IV | `Features_cost_updated_all_116_features.xlsx` |
| V | `Cost_Manufacturing_Feature_Acquisition_Costs.xlsx` |
| VI | `Cost_Water_Potability_Feature_Acquisition_Costs.xlsx` |
| VII | `Cost_Kidney_Disease_Feature_Acquisition_Cos_.xlsx` |
| VIII | `cost_Diabetes_Progression_Feature.xlsx` |

Feature-cost processing is implemented in `p2cafs/costs.py`. Feature-level tables use the fields `Feature`, `cost_sensors`, and `cost_lab`. Dataset column names must correspond to the feature names in the relevant workbook.

## Installation

Python 3.10 or later is recommended. Open a terminal in the `P2CAFS` directory and create a virtual environment:

```bash
python -m venv .venv
```

Activate it on Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Or on Linux/macOS:

```bash
source .venv/bin/activate
```

Install the dependencies and launch JupyterLab:

```bash
python -m pip install -r requirements.txt
python -m pip install jupyterlab openpyxl
jupyter lab
```

## Running P²CAFS

Launch JupyterLab from the repository root so the local `p2cafs` package can be imported. Open the notebook corresponding to the required operating mode:

| Operating mode | Notebook | Datasets |
|---|---|---|
| Joint regression and classification | `03_Joint_Baseline_Comparison.ipynb` | I–V |
| Classification only | `01_Classification.ipynb` | VI–VII |
| Regression only | `02_Regression_Baseline_Comparison_MINIMAL_EDIT.ipynb` | VIII |

1. Open the relevant notebook.
2. Set the dataset path, target column(s), and associated feature-cost workbook for the selected dataset.
3. Check the notebook's experiment configuration and any required input-file paths.
4. Run the notebook cells in order using **Run All** or sequential execution.

The notebooks contain experiment-specific configurations. Some cells reference local paths or generated Excel files; those paths must resolve in the execution environment. The regression notebook also uses scikit-learn's `load_diabetes()` loader, which provides the diabetes dataset used in that experiment.

## Dataset sources

The following links identify the original sources of the agricultural datasets. Dataset I is based on the Rwanda Soil Nutrient Balance dataset; the repository dataset may include additional variables or processing.

| Dataset | Source | Link |
|---|---|---|
| I | Uwiragiye et al. (2022), *Soil Nutrient Balance (NPK) Dataset of Rwanda*, Version 2 | [Zenodo](https://doi.org/10.5281/zenodo.7112371) |
| II | MadhanKumar, *Crop Yield and Environmental Factors (2014–2023)* | [Kaggle](https://www.kaggle.com/datasets/madhankumar789/crop-yield-and-environmental-factors-2014-2023) |
| III | Rajan Amrelia, *All India Crop and Climate Dataset (1984–2017)* | [Kaggle](https://www.kaggle.com/datasets/rajanamrelia/all-india-crop-and-climate-dataset-19842017) |
| IV | zoya77, *Indian Historical Crop Yield and Weather Data* | [Kaggle](https://www.kaggle.com/datasets/zoya77/indian-historical-crop-yield-and-weather-data) |
| V | williamsewell, *Manufacturing Quality Decisions* | [Kaggle](https://www.kaggle.com/datasets/williamsewell/manufacturing-quality-decisions) |
| VI | adityakadiwal, *Water Potability* | [Kaggle](https://www.kaggle.com/datasets/adityakadiwal/water-potability) |
| VII | mansoordaku, *Chronic Kidney Disease* | [Kaggle](https://www.kaggle.com/datasets/mansoordaku/ckdisease) |
| VIII | *Diabetes* dataset, scikit-learn | [scikit-learn](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_diabetes.html) |

Dataset use and redistribution are subject to the licenses and terms of the original sources.
